/*
 * NAME: lcd.c
 * AUTHOR:
 * PROJECT:
 * DATE:
 * CODE REVISION:
 * PURPOSE OF FILE:
*/

#include "lcd.h"

enum typeofdata
{
    command = 0,
    data
};

static void LcdWrite(enum typeofdata type, uint8_t data)
{
    LCD_DATA_LAT        = data;  // Put data on databus
    LCD_CONTROL_RS_LAT  = type;  // Pull RS high for data/low for command.
    LCD_CONTROL_E_LAT   = 1;     // Pull E high...
    __delay_us(1);		 // ...wait at least 300ns...
    LCD_CONTROL_E_LAT   = 0;     // ...and pull E down, this will clock the data in.
    // Write complete.

    // Instead of polling LCD busy bit, just busywait until it's done for sure.
    __delay_us(60);
    /* Clear display (and Return home command) needs ~1.6ms to execute,
       deal with that in their own functions. */
}

void LcdInit(void)
{
	__delay_ms(40);
        LCD_DATA_TRIS       = 0x00;
        LCD_CONTROL_E_TRIS  = 0;
        LCD_CONTROL_RW_TRIS = 0;
        LCD_CONTROL_RS_TRIS = 0;

        LCD_CONTROL_RS_LAT  = 0;
        LCD_CONTROL_RW_LAT  = 0;

        //ENTRY MODE SET
        LcdWrite(command, 0b00000100);
        __delay_us(40);

        //DISPLAY ON/OFF CONTROL
        LcdWrite(command, 0b00001100);
        __delay_us(40);

        //FUNCTION SET
        LcdWrite(command, 0b00111100);
        __delay_us(40);

	LcdClear();
}

void LcdClear(void)
{
    LCD_CONTROL_RW_LAT = 0;

    LcdWrite(command, 0b00000001);
    __delay_ms(2);

    LcdWrite(command, 0b00000010);
    __delay_ms(2);
}

void LcdPutchar(char c)
{
    LCD_CONTROL_RW_LAT = 0;
    LcdWrite(data,c);
    __delay_us(43);
}

void LcdPutstring(char *str)
{
    LCD_CONTROL_RW_LAT = 0;
    while(*str)
        LcdPutchar(*str++);
}

void LcdGoToXY(int8_t x, int8_t y)
{
    int8_t P;
    LcdWrite(command, 0b00000010);
    __delay_ms(2);
    if(y == 1)
    {
        P = 0b10000000 + x;
        LcdWrite(command,P);
    }
    else
    {
        P = 0b10000000 + x + 0x40;
        LcdWrite(command,P);
    }
    __delay_us(43);
}
