/*
 * NAME: temp.h
 * AUTHOR:
 * PROJECT:
 * DATE:
 * CODE REVISION:
 * PURPOSE OF FILE:
*/

#ifndef TEMP_H
#define	TEMP_H


#define FOSC (8000000UL)
#define FCY (FOSC/2)
#include <libpic30.h>  // To be able to use __delay_ms();
#include <xc.h> // include processor files
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>

/*******************************
 TempCalc
 *  Function description:
 *    Uses an analog value to calculates the correct temperature in Celcius.
 *    Then returns the temperature.
 *
 *  Input: uint16_t adc_10bit
 *  Output: unsigned int temp

 *******************************/
unsigned int TempCalc(uint16_t adc10Bit);

/*******************************
 CheckTemp
 *  Function description:
 *    Checks what the current temperature is and compares it to the min and max
 *    values thats been set by the user. Then decides if the fan should be on
 *    or off
 *
 *  Input: int temp, int tempMinLimit, int tempMaxLimit
 *  Output: int fan
 *******************************/
int CheckTemp(int temp, int tempMinLimit, int tempMaxLimit);

#endif	/* TEMP_H */

