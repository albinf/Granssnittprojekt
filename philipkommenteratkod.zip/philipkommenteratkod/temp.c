/*
 * NAME: temp.c
 * AUTHOR:
 * PROJECT:
 * DATE:
 * CODE REVISION:
 * PURPOSE OF FILE:
*/

#include "temp.h"

unsigned int temp_calc(uint16_t adc10Bit)
{
    unsigned int temp;
    temp = -39 * adc10Bit+ 50000;
    return temp;
}

int checktemp(int temp, int tempMinLimit, int tempMaxLimit)
{
    static int fan = 0;
    if (fan == 0)
    {
        if (temp >= tempMaxLimit)
        {
            fan = 1;
        }
    }
    else
    {
        if (temp < tempMinLimit)
        {
            fan = 0;
        }
    }
    return fan;
}



