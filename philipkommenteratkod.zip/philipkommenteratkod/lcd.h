/*
 * NAME: lcd.h
 * AUTHOR:
 * PROJECT:
 * DATE:
 * CODE REVISION:
 * PURPOSE OF FILE:
*/

#ifndef LCD_H
#define	LCD_H

#define FOSC (8000000UL)
#define FCY (FOSC/2)
#include <libpic30.h>  // To be able to use __delay_ms();
#include <xc.h> // include processor files
#include <stdint.h>

#define LCD_DATA_LAT        LATE  // Lower 8 bits used.
#define LCD_DATA_TRIS       TRISE

#define LCD_CONTROL_E_LAT     _LATD4
#define LCD_CONTROL_E_TRIS    _TRISD4

#define LCD_CONTROL_RW_LAT    _LATD5
#define LCD_CONTROL_RW_TRIS    _TRISD5

#define LCD_CONTROL_RS_LAT    _LATB15
#define LCD_CONTROL_RS_TRIS   _TRISB15

/*******************************
 LcdWrite
 *  Function description:
 *    Enables the LCD-display to accept data or a command.
 *    Input: enum typeofdata type, uint8_t data
 *    Output: None
 *******************************/
static void LcdWrite(enum typeofdata type, uint8_t data);

/*******************************
 LcdInit
 *  Function description:
 *    Sets the initial settings for the LCD-display.
 *    Input: None
 *    Output: None
 *******************************/
void LcdInit(void);

/*******************************
 LcdClear
 *  Function description:
 *    Clears the LCD-display and sets the cursor to the first position. 
 *    Input: None
 *    Output: None 
 *******************************/
void LcdClear(void);

/*******************************
 LcdGoToXY
 *  Function description:
 *    Moves the cursor to a position on the LCD-display determined by the
 *    x and y values.
 *    Input: int8_t x, int8_t y
 *    Output: None
 *******************************/
void LcdGoToXY(int8_t x, int8_t y);

/*******************************
 LcdPutchar
 *  Function description:
 *    Writes a single character on the display.
 *    Input: char c
 *    Output: None
 *******************************/
void LcdPutChar(char c);

/*******************************
 LcdPutString
 *  Function description:
 *    Writes Writes a string on the display. Uses the function LcdPutChar to
 *    write single characters as long as there is any characters left in the
 *    string.
 *    Input: char *str
 *    Output: None
 *******************************/
void LcdPutString(char *str);


#endif