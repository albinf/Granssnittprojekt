/* 
 * File:   main.c
 * Author: heja1414
 *
 * Created on den 22 mars 2016, 12:59
 */
#define FOSC (8000000UL)
#define FCY (FOSC/2)
#include <stdio.h>
#include <stdlib.h>
#include <libpic30.h>


// PIC24FJ128GA010 Configuration Bit Settings

// 'C' source line config statements

#include <xc.h>
#include "mpr121.h"

// CONFIG2
#pragma config POSCMOD = XT             // Primary Oscillator Select (XT Oscillator mode selected)
#pragma config OSCIOFNC = OFF           // Primary Oscillator Output Function (OSC2/CLKO/RC15 functions as CLKO (FOSC/2))
#pragma config FCKSM = CSDCMD           // Clock Switching and Monitor (Clock switching and Fail-Safe Clock Monitor are disabled)
#pragma config FNOSC = PRI              // Oscillator Select (Primary Oscillator (XT, HS, EC))
#pragma config IESO = ON                // Internal External Switch Over Mode (IESO mode (Two-Speed Start-up) enabled)

// CONFIG1
#pragma config WDTPS = PS32768          // Watchdog Timer Postscaler (1:32,768)
#pragma config FWPSA = PR128            // WDT Prescaler (Prescaler ratio of 1:128)
#pragma config WINDIS = OFF             // Watchdog Timer Window (Windowed Watchdog Timer enabled; FWDTEN must be 1)
#pragma config FWDTEN = OFF             // Watchdog Timer Enable (Watchdog Timer is disabled)
#pragma config ICS = PGx2               // Comm Channel Select (Emulator/debugger uses EMUC2/EMUD2)
#pragma config GWRP = OFF               // General Code Segment Write Protect (Writes to program memory are allowed)
#pragma config GCP = OFF                // General Code Segment Code Protect (Code protection is disabled)
#pragma config JTAGEN = ON// JTAG Port Enable (JTAG port is enabled)



#define SDA_PORT PORTAbits.RA3
#define SCL_PORT PORTAbits.RA2

#define SDA_TRIS TRISAbits.TRISA3
#define SCL_TRIS TRISAbits.TRISA2

#define SDA_LAT LATAbits.LATA3
#define SCL_LAT LATAbits.LATA2

char read_touch =0;
void _ISR INT2Interrupt()
{
    read_touch = 1;
    _INT2IF = 0;
}

/*
 * 
 */
void MainInit()
{
    TRISAbits.TRISA6 = 0;
    TRISEbits.TRISE9 = 1;
    //LATEbits.LATE9 = 1;
    //TRISEbits.TRISE9 = 1;

    _INT2IE = 1;
    _INT2EP = 1;

    SDA_TRIS = 0;
    SCL_TRIS = 0;
    SDA_LAT = 0;
    SCL_LAT = 0;
    int temp;
    I2C2BRG = 0x27;
    //I2C2CON = 0b1000000000000000;
    I2C2CONbits.I2CEN = 0;
    I2C2CONbits.DISSLW = 1;
     I2C2CONbits.I2CEN = 1;
    I2C2ADD = 0X5A;
    temp = I2C2RCV;
    //I2CStop();




}
void reset_i2c_bus(void)
{
   int x = 0;

   //initiate stop bit
   I2C1CONbits.PEN = 1;

   //wait for hardware clear of stop bit
   while (I2C1CONbits.PEN)
   {
      __delay_us(1);
      x ++;
      if (x > 20) break;
   }
   I2C1CONbits.RCEN = 0;
   IFS1bits.MI2C1IF = 0; // Clear Interrupt
   I2C1STATbits.IWCOL = 0;
   I2C1STATbits.BCL = 0;
   __delay_us(10);
}



void I2CStart()
{
    I2C2CONbits.SEN = 1;
    while(I2C2CONbits.SEN == 1);
}
void I2CStop()
{
    I2C2CONbits.PEN = 1;
     while(I2C2CONbits.PEN == 1);
}
void I2CReStart()
{
    I2C2CONbits.RSEN = 1;
    while(I2C2CONbits.RSEN == 1);
}
/*void I2CWait()
{
     while ( ( SSP1CON2 & 0x1F ) || ( SSPSTAT & 0x04 ) );
}*/
void I2CSlaveAdress()
{
    I2C2TRN = 0b00011000;
   while(I2C2STATbits.TBF == 1);
}


int read_byte(int registeradd)
{
    int recv_byte;
    I2CStart();
    I2C2TRN = 0b10110100;
    while(I2C2STATbits.TRSTAT == 1);
    I2C2TRN = registeradd;
    while(I2C2STATbits.TRSTAT == 1);
    I2CReStart();
    I2C2TRN = 0b10110101;
    while(I2C2STATbits.TRSTAT == 1);
    recv_byte = I2C2RCV;
    I2C2CONbits.ACKDT = 1;
    I2C2CONbits.ACKEN = 1;
    while(I2C2CONbits.ACKEN == 1);
    I2CStop();
    return recv_byte;


}

void send_byte(int registeradd, int data)
{
    I2CStart();
    I2C2TRN = 0b10110100;
    while(I2C2STATbits.TRSTAT == 1);
    I2C2TRN = registeradd;
    while(I2C2STATbits.TRSTAT == 1);
    I2C2TRN = data;
    while(I2C2STATbits.TRSTAT == 1);
    I2CStop();
}



void mpr121QuickConfig(void)
{
  send_byte(ELE_CFG, 0x00);
  // Section A
  // This group controls filtering when data is > baseline.
  send_byte(MHD_R, 0x01);
  send_byte(NHD_R, 0x01);
  send_byte(NCL_R, 0x00);
  send_byte(FDL_R, 0x00);

  // Section B
  // This group controls filtering when data is < baseline.
  send_byte(MHD_F, 0x01);
  send_byte(NHD_F, 0x01);
  send_byte(NCL_F, 0xFF);
  send_byte(FDL_F, 0x02);

  // Section C
  // This group sets touch and release thresholds for each electrode
  send_byte(ELE0_T, TOU_THRESH);
  send_byte(ELE0_R, REL_THRESH);
  send_byte(ELE1_T, TOU_THRESH);
  send_byte(ELE1_R, REL_THRESH);
  send_byte(ELE2_T, TOU_THRESH);
  send_byte(ELE2_R, REL_THRESH);
  send_byte(ELE3_T, TOU_THRESH);
  send_byte(ELE3_R, REL_THRESH);
  send_byte(ELE4_T, TOU_THRESH);
  send_byte(ELE4_R, REL_THRESH);
  send_byte(ELE5_T, TOU_THRESH);
  send_byte(ELE5_R, REL_THRESH);
  send_byte(ELE6_T, TOU_THRESH);
  send_byte(ELE6_R, REL_THRESH);
  send_byte(ELE7_T, TOU_THRESH);
  send_byte(ELE7_R, REL_THRESH);
  send_byte(ELE8_T, TOU_THRESH);
  send_byte(ELE8_R, REL_THRESH);
  send_byte(ELE9_T, TOU_THRESH);
  send_byte(ELE9_R, REL_THRESH);
  send_byte(ELE10_T, TOU_THRESH);
  send_byte(ELE10_R, REL_THRESH);
  send_byte(ELE11_T, TOU_THRESH);
  send_byte(ELE11_R, REL_THRESH);

  // Section D
  // Set the Filter Configuration
  // Set ESI2
  send_byte(FIL_CFG, 0x04);

  // Section E
  // Electrode Configuration
  // Enable 6 Electrodes and set to run mode
  // Set ELE_CFG to 0x00 to return to standby mode
  //send_byte(ELE_CFG, 0x0C);	// Enables all 12 Electrodes
  send_byte(ELE_CFG, 0b00001001);		// Enable first 6 electrodes

  // Section F
  // Enable Auto Config and auto Reconfig
  /*send_byte(ATO_CFG0, 0x0B);
  send_byte(ATO_CFGU, 0xC9);	// USL = (Vdd-0.7)/vdd*256 = 0xC9 @3.3V
  send_byte(ATO_CFGL, 0x82);	// LSL = 0.65*USL = 0x82 @3.3V
  send_byte(ATO_CFGT, 0xB5);	// Target = 0.9*USL = 0xB5 @3.3V
  send_byte(ELE_CFG, 0x06);*/
}


int main(int argc, char** argv) {

   LATAbits.LATA6 = 0;
   int incomming = 0;
   MainInit();
   reset_i2c_bus();
   mpr121QuickConfig();
   while(1)
   {

        //mpr121QuickConfig();
       if(read_touch){
           incomming = read_byte(0x00);
           LATAbits.LATA6 = 1;
           read_touch = 0;
       }
       //LATAbits.LATA6 = 1;
       //mpr121QuickConfig();
       /* I2CStart();
        I2C2TRN = 0b10110100;
        while(I2C2STATbits.TRSTAT == 1);
        I2C2TRN = 0x2B;
        while(I2C2STATbits.TRSTAT == 1);
        I2C2TRN = 0b00000001;
        while(I2C2STATbits.TRSTAT == 1);
        I2CStop();
        __delay_us(50);*/

        //send_byte(0x2B, 0b00000001);
    
    
    }
    return (EXIT_SUCCESS);
}

