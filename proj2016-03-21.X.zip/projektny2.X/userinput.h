/* 
 * File:   userinput.h
 * Author: heja1414
 *
 * Created on den 16 mars 2016, 09:43
 */

#ifndef USERINPUT_H
#define	USERINPUT_H

/*#ifdef	__cplusplus
extern "C" {
#endif*/

#include <stdlib.h>
#include <xc.h>
#include <libpic30.h>
#include "helperfunctions.h"

struct input
{
    int window;
    int button;
    int tempMaxLimit;
    int tempMinLimit;
};

struct input UserInputInit(struct input uninit);
struct input EncoderPosition(struct input inputPosition, int direction);
struct input ConfirmSelection(struct input inputPosition);




/*#ifdef	__cplusplus
}
#endif*/

#endif	/* USERINPUT_H */

