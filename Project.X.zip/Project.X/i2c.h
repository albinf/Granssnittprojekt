/* 
 * File:   i2c.h
 * Author: Albin
 *
 * Created on den 22 mars 2016, 10:37
 */

#ifndef I2C_H
#define	I2C_H

#define SDA_PORT PORTAbits.RA3
#define SCL_PORT PORTAbits.RA2
#define SDA_LAT LATAbits.LATA3
#define SCL_LAT LATAbits.LATA2

void i2c_init();



#endif	/* I2C_H */

