#include "TEMP.h"

uint16_t temp_calc(uint16_t ADC_10bit)
{
    uint16_t temp;
    temp = (-0.0391006843*ADC_10bit+50.0)*10;//*1000;
   // temp=(-391*adc*+50);
    return temp;
}

int checktemp(float float_temp, int tempminlimit, int tempmaxlimit)
{
    static int fan = 0;
    if (fan == 0)
    {
        if (float_temp >= tempmaxlimit)
        {
            fan = 1;
        }
    }
    else
    {
        if (float_temp <= tempminlimit)
        {
            fan = 0;
        }
    }
    return fan;
}


