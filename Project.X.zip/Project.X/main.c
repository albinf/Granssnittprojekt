/*
 * File:   main.c
 * Author: Albin
 *
 * Created on den 27 februari 2016, 14:13
 */

#include "xc.h"

// CONFIG2
#pragma config POSCMOD = XT             // Primary Oscillator Select (XT Oscillator mode selected)
#pragma config OSCIOFNC = OFF           // Primary Oscillator Output Function (OSC2/CLKO/RC15 functions as CLKO (FOSC/2))
#pragma config FCKSM = CSDCMD           // Clock Switching and Monitor (Clock switching and Fail-Safe Clock Monitor are disabled)
#pragma config FNOSC = PRI              // Oscillator Select (Primary Oscillator (XT, HS, EC))
#pragma config IESO = ON                // Internal External Switch Over Mode (IESO mode (Two-Speed Start-up) enabled)

#pragma config FWDTEN = OFF             // Watchdog Timer Enable (Watchdog Timer is disabled)
#pragma config JTAGEN = OFF             // JTAG Port Enable (JTAG port is disabled)



#define FOSC (8000000UL)
#define FCY (FOSC/2)

#include <libpic30.h>  // To be able to use __delay_ms();

#include <xc.h> // include processor files
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>



#define FOSC (8000000UL)
#define FCY (FOSC/2)

#define CW 1
#define CCW -1
#define Idlemove 3

char str[17];
int riktning = 0;
uint16_t ADC_10bit = 0b0000000000;
uint16_t temp = 0;
int tempmaxlimit = 32;
int tempminlimit = 25;
//void _ISR _INT0Interrupt(void){
//    if(AD1CON1bits.DONE){
//       TEMP_16bit = ADC1BUF0;
//    }
//}
void _ISR _INT3Interrupt(void)
{
        if(_RD7 == 0){ //clockwise
            if(!_INT3EP)
                riktning = CW;
            else
                riktning = CCW;
        }
        if(_RD7 == 1){ //counter clockwise
            if(!_INT3EP)
                riktning = CCW;
            else
                riktning = CW;
        }
        _INT3EP = !_INT3EP;
        _INT3IF = 0;
}

//RD7,RA14  encoder
//RA3 KNAPP p� encoder
void init(void){
    TRISAbits.TRISA3 = 1;
    _INT3IE = 1;
    _INT3EP = 0;//pos FLANK
}
int main(void)
{
    init();
    lcd_init();
    ADC_INIT();
    while(1){
        lcd_clear();
        ADC_10bit = ADC_READ();

        temp = temp_calc(ADC_10bit);
        float float_temp = ((double)temp) / 10;// I have no idea what im doing
        //float test = checktemp(float_temp, tempminlimit, tempmaxlimit);
        float test = temp_bar(float_temp, tempminlimit, tempmaxlimit);
        sprintf(str,"%d = %.1f",ADC_10bit,float_temp);
        lcd_gotoxy(0,1);
        lcd_putstring(str);
        lcd_putchar(0b11011111);
        lcd_putchar(0b01000011);
        __delay_ms(50);
        //static unsigned char state = 0;
        //static unsigned char val = 0;


/*        switch(state){

            case 0: // HOME SCREEN WRITE
                lcd_clear();
                sprintf(str,"%d",riktning);
                lcd_gotoxy(0,1);
                lcd_putstring(str);
                __delay_ms(20);
                 if(PORTAbits.RA3 == 1){
                    state = 1;
                }
//                lcd_gotoxy(0,2);
//                lcd_putstring("[|||||       ]");
                
                
                //if(riktning == 1){

                //state = 0;
                //}
                break;
            case 1:
                if(PORTAbits.RA3 == 0){

                    state = 2;
                }
                break;
            case 2://Config

                val = 1;
                lcd_clear();
                lcd_gotoxy(0,1);
                lcd_putstring("Min:xx | Max:xx");
                lcd_gotoxy(0,2);
                lcd_putstring("Back");
                lcd_choice();
                if(val == 1){

                    lcd_gotoxy(5,1);
                    __delay_ms(10);

                    if(riktning == CW){
                        val = 2;
                    }
                    else
                        val = 3;
                }
                else if(val == 2){
                    lcd_gotoxy(14,1);
                    __delay_ms(20);
                    if(riktning == CW){
                        val = 3;
                    }
                    else
                        val = 1;
                }
                else{
                    lcd_gotoxy(0,2);
                    __delay_ms(5);
                    lcd_gotoxy(1,2);
                    __delay_ms(5);
                    lcd_gotoxy(2,2);
                    __delay_ms(5);
                    lcd_gotoxy(3,2);
                    __delay_ms(5);
                    if(riktning == CW){
                        val = 1;
                    }
                    else
                        val = 2;

                }
                //riktning = 0;



                //lcd_choice(riktning, state);
                __delay_ms(20);

                if(PORTAbits.RA3 == 1){
                    
                    state = 3;
                }
                break;

                 case 3:
                if(PORTAbits.RA3 == 0){

                    state = 0;
                }
                break;

        }
 */
    }
}

