/* 
 * File:   gui.h
 * Author: Albin
 *
 * Created on den 18 mars 2016, 09:28
 */

#ifndef GUI_H
#define	GUI_H

#define FOSC (8000000UL)
#define FCY (FOSC/2)

#include "userinput.h"
#include "helperfunctions.h"
#include "lcd.h"
#include <xc.h>
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <libpic30.h>
struct displayData
{
    int heltals;
    int decimals;
    int firstdecimal;
};

struct displayData DisplayInit(struct displayData uninitTemp);
void writewindow(struct input inputPosition, struct displayData temp);
void temp_bar(int temp, int tempminlimit,int tempmaxlimit);
struct displayData SplitNumber(unsigned int temp);



#endif	/* GUI_H */

