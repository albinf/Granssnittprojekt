#include "gui.h"



struct displayData DisplayInit(struct displayData uninitTemp){
    uninitTemp.decimals = 0;
    uninitTemp.heltals = 0;
    uninitTemp.firstdecimal = 0;
    return uninitTemp;

}


void writewindow(struct input inputPosition, struct displayData temp){
    char str[17];
    if(inputPosition.window == 0 && inputPosition.button == 0){//HOME
        
        lcd_gotoxy(0, 1);
        sprintf(str,"T:%d.%d |  CONFIG",temp.heltals,temp.firstdecimal);
        lcd_putstring(str);

        static int i = 0;
        i++;
        if(i == 50){
            lcd_gotoxy(0, 2);
            temp_bar(temp.heltals,10,50);
            i = 0;
        }
        //lcd_clear();

    }
    else if(inputPosition.window == 0 && inputPosition.button == 1){//HOME och mark�r
        lcd_gotoxy(0, 1);
        sprintf(str,"T:%d.%d | *CONFIG",temp.heltals,temp.firstdecimal);
        lcd_putstring(str);

        static int i = 0;
        i++;
        if(i == 50){
            lcd_gotoxy(0, 2);
            temp_bar(temp.heltals,10,50);
            i = 0;
        }
         

        //lcd_clear();


    }
    else if(((inputPosition.window == 1) || (inputPosition.window == 2)) && inputPosition.button == 0){//CONFIG och mark�r min

        lcd_gotoxy(0, 1);
        sprintf(str,"*MIN:%d | MAX:%d",inputPosition.tempMinLimit,
                                       inputPosition.tempMaxLimit);
        lcd_putstring(str);

        lcd_gotoxy(0, 2);
        sprintf(str," Back");
        lcd_putstring(str);

    }
    else if(((inputPosition.window == 1) || (inputPosition.window == 3)) && inputPosition.button == 1){//CONFIG och mark�r max
        lcd_gotoxy(0, 1);
        sprintf(str," MIN:%d |*MAX:%d",inputPosition.tempMinLimit,
                                       inputPosition.tempMaxLimit);
        lcd_putstring(str);

        lcd_gotoxy(0, 2);
        sprintf(str," Back");
        lcd_putstring(str);


    }
    else if(inputPosition.window == 1 && inputPosition.button == 2){//CONFIG och mark�r back
        lcd_gotoxy(0, 1);
        sprintf(str," MIN:%d | MAX:%d",inputPosition.tempMinLimit,
                                       inputPosition.tempMaxLimit);
        lcd_putstring(str);

        lcd_gotoxy(0, 2);
        sprintf(str,"*Back");
        lcd_putstring(str);


    }
    else if(inputPosition.window == 2){//MIN



    }
    else if(inputPosition.window == 3){//MAX



    }

}

void temp_bar(int temp, int tempminlimit,int tempmaxlimit)
{
    lcd_clear();
       //MAX BARS 16
    //MIN BARS 1
    static int bars;
    bars = 0;
    int steg = 3;
    int k;
    for(k = tempminlimit; k <= temp;)
    {
        bars = bars + 1;
        k = k + steg;
    }
    
    //lcd_clear();
    int i;
    for (i = 0; i<bars; i++){
        lcd_gotoxy(i, 2);
        lcd_putchar(0b11111111);
    }
    
}

struct displayData SplitNumber(unsigned int temp)
{
    struct displayData blaa;
    int i;
    int bla = 0;
    int decimal = 0;
    for(i = 0; i < 3; i++)
    {
        //printf( "%d\n", num % 10 ) ;
        bla = temp % 10;
        //printf( "%d\n", bla );
        temp = temp / 10 ;
        decimal = decimal +bla*ipow(10, i);
        if(i == 2){
            blaa.firstdecimal = bla;
        }
    }
    blaa.heltals = temp;
    blaa.decimals = decimal;
    return blaa;
}