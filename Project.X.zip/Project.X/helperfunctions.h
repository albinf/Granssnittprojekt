/* 
 * File:   helperfunctions.h
 * Author: heja1414
 *
 * Created on den 16 mars 2016, 10:23
 */

#ifndef HELPERFUNCTIONS_H
#define	HELPERFUNCTIONS_H
#include "gui.h"
#include <stdlib.h>
#include <xc.h>
#include <libpic30.h>



int LimitModulo(int limit, int direction, int value);
int LimitStop(int upperLimit, int lowerLimit, int direction, int value);
int ChangeOnRelease();
int ipow(int base, int exp);


#endif	/* HELPERFUNCTIONS_H */

