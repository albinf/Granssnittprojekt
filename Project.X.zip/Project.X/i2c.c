#include "i2c.h"

#define I2C_adressR 0b10110101
#define I2C_adressW 0b10110100

void i2c_init(){
//    I2C2CON = 0b1000000000000000;
//    I2C2ADD = 0x5A;
//    I2C2BRG = 0x25;
//    SDA_LAT = 1;
//    SCL_LAT = 1;
//
//    I2C2CONbits.SEN = 1;//SKICKAR START
//    I2C2TRN = I2C_adressW;
//    I2C2TRN = 0x00;

//    I2C2CONbits.RSEN = 1; // REPEATED START
//    I2C2TRN = I2C_adressR;
//
//
//    I2C2TRN = 0x01;
//    I2C2CONbits.ACKEN = 1; // MAKE ACK
//    I2C2CONbits.PEN = 1; // SKICKAR STOPP
//
//
}


