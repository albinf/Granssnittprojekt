/*
 * NAME: GUI.h
 * AUTHOR:
 * PROJECT:
 * DATE: 16 mars 2016, 09:43
 * CODE REVISION:
 * PURPOSE OF FILE:
 */
#ifndef GUI_H
#define	GUI_H

#define FOSC (8000000UL)
#define FCY (FOSC/2)

#include "userinput.h"
#include "helperfunctions.h"
#include "lcd.h"
#include <xc.h>
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <libpic30.h>
struct displayData
{
    int heltals;
    int decimals;
    int firstDecimal;
};

/**
 ******************************************************************************
 * DisplayInit
 *      Function Description:
 *          Set default values
 *      Input: struct displayData
 *      Output: struct displayData
 * ****************************************************************************
 */
struct displayData DisplayInit(struct displayData unInitTemp);
/**
 ******************************************************************************
 * WriteWindow
 *      Function Description:
 *          Calls the lcd module with what to write on the lcd screen.
 *          The "window" and button variables are used to what is being drawed
 *          also takes the displayData were the temperature is and prints it out
 *          the home screen.
 *      Input: struct input, struct displayData
 *      Output: NULL
 * ****************************************************************************
 */
void WriteWindow(struct input inputPosition, struct displayData temp);
/**
 ******************************************************************************
 * TempBar
 *      Function Description:
 *          Makes a grafical simulation of the temperature, and calls the LCD module
 *          to print it out
 *      Input: int Temperature, int tempMinLimit, tempMaxLimit
 *      Output: NULL
 * ****************************************************************************
 */
void TempBar(int temp, int tempMinLimit);
/**
 ******************************************************************************
 * SplitNumber
 *      Function Description:
 *          Takes the Temperature value that just now is XXXXX and splits it to
 *          integer and decimals.
 *      Input: unsigned int Temperature
 *      Output: struct displayData
 * ****************************************************************************
 */
struct displayData SplitNumber(unsigned int temp);



#endif	/* GUI_H */

