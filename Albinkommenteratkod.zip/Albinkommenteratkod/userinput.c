/*
 * NAME:
 * AUTHOR:
 * PROJECT:
 * DATE: 16 mars 2016, 09:43
 * CODE REVISION:
 * PURPOSE OF FILE:
 */

#include "userinput.h"
struct input UserInputInit(struct input unInit)
{
    unInit.window = 0;
    unInit.button = 1;
    unInit.tempMaxLimit = 50;
    unInit.tempMinLimit = 10;
    return unInit;
}
struct input EncoderPosition(struct input inputPosition, int direction)
{
    if(inputPosition.window == 0)//HOME
    {
        inputPosition.button = LimitModulo(2, direction,inputPosition.button);
    }
    else if(inputPosition.window == 1)//CONFIG
    {
        inputPosition.button = LimitModulo(3, direction,inputPosition.button);
    }
    else if(inputPosition.window == 2)
    {
       //inputPosition.tempMaxLimit+= direction;
       inputPosition.tempMinLimit = LimitStop( inputPosition.tempMaxLimit-1,
                                              10,
                                              direction,
                                              inputPosition.tempMinLimit);
    }
    else if(inputPosition.window == 3)
    {
        inputPosition.tempMaxLimit = LimitStop(50,
                                              inputPosition.tempMinLimit+1,
                                              direction,
                                              inputPosition.tempMaxLimit);
    }
    return inputPosition;
}
struct input ConfirmSelection(struct input inputPosition)
{
    if(inputPosition.window == 0 && inputPosition.button == 0)//HOME
    {
        inputPosition.window = 0;
    }
    else if(inputPosition.window == 0 && inputPosition.button == 1)//HOME and button
    {
        inputPosition.window = 1;
    }
    else if(inputPosition.window == 1 && inputPosition.button == 0)//Min
    {
        inputPosition.window = 2;
    }
    else if(inputPosition.window == 1 && inputPosition.button == 1)//Max
    {
        inputPosition.window = 3;
    }
    else if(inputPosition.window == 1 && inputPosition.button == 2)//BACK
    {
        inputPosition.window = 0;
        inputPosition.button = 0; // Set the button to 0 because otherwise it will be out of range
    }
    else if(inputPosition.window == 2 || inputPosition.window == 3)//TILLBAKS TILL CONFIG
    {
        inputPosition.window = 1;
    }
    return inputPosition;
}