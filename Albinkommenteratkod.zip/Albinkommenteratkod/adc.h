/*
 * NAME: GUI.h
 * AUTHOR:
 * PROJECT:
 * DATE: 16 mars 2016, 09:43
 * CODE REVISION:
 * PURPOSE OF FILE:
 */
#ifndef ADC_H
#define	ADC_H

#include <xc.h>
#include <stdint.h>
#include <stdbool.h>
#include <libpic30.h>  // To be able to use __delay_ms();

/******************************************************************************
 * ADCInit
 *      Function Description:
 *          Sets the initial settings for the ADC
 *      Input: NULL
 *      Output: NULL
 * ****************************************************************************/
void ADCInit(void);
/******************************************************************************
 * ADCRead
 *      Function Description:
 *          Starts a sample conversion of the temperature and returns the adc value
 *      Input: NULL
 *      Output: ADC1BUF0
 * ****************************************************************************/
uint16_t ADCRead(void);

#endif	/* ADC_H */

