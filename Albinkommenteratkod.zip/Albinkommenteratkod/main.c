/*
 * NAME: main.c
 * AUTHORS: Adam Andersson, Albin Fransson, Jacob Hejderup och Philip Larsson,
 * PROJECT:
 * DATE: 16 mars 2016, 09:43
 * CODE REVISION:
 * PURPOSE OF FILE:
 *
 * RD7,RA14  encoder
 * RA3 KNAPP p� encoder
 */

#include <stdio.h>
#include <stdlib.h>
#include "xc.h"
#include <libpic30.h>
#include "helperfunctions.h"
#include "userinput.h"
#include "lcd.h"
#include "temp.h"
#include "adc.h"
#include "gui.h"



/*
 * 
 */
#define FOSC (8000000UL)
#define FCY (FOSC/2)

// CONFIG2
#pragma config POSCMOD = XT             // Primary Oscillator Select (XT Oscillator mode selected)
#pragma config OSCIOFNC = OFF           // Primary Oscillator Output Function (OSC2/CLKO/RC15 functions as CLKO (FOSC/2))
#pragma config FCKSM = CSDCMD           // Clock Switching and Monitor (Clock switching and Fail-Safe Clock Monitor are disabled)
#pragma config FNOSC = PRI              // Oscillator Select (Primary Oscillator (XT, HS, EC))
#pragma config IESO = ON                // Internal External Switch Over Mode (IESO mode (Two-Speed Start-up) enabled)

// CONFIG1
#pragma config WDTPS = PS32768          // Watchdog Timer Postscaler (1:32,768)
#pragma config FWPSA = PR128            // WDT Prescaler (Prescaler ratio of 1:128)
#pragma config WINDIS = OFF             // Watchdog Timer Window (Windowed Watchdog Timer enabled; FWDTEN must be 1)
#pragma config FWDTEN = OFF             // Watchdog Timer Enable (Watchdog Timer is disabled)
#pragma config ICS = PGx2               // Comm Channel Select (Emulator/debugger uses EMUC2/EMUD2)
#pragma config GWRP = OFF               // General Code Segment Write Protect (Writes to program memory are allowed)
#pragma config GCP = OFF                // General Code Segment Code Protect (Code protection is disabled)
#pragma config JTAGEN = ON

#define CW -1
#define CCW 1
unsigned int temp = 0;
char str[17];
uint16_t adc10Bit = 0b0000000000;
int riktning = 0;
int msCounter = 0;
int msCounter2 = 0;
char startRead = 0;
char startDraw = 0;
struct input h_input;
struct displayData h_displayData;
void _ISR _T1Interrupt (void)//varje 1 ms
{

    msCounter++;
    msCounter2++;
    if(msCounter == 50)
    {
        msCounter = 0;
        startRead = 1;
    }
    if(msCounter2 == 100){
        msCounter2 = 0;
        startDraw = 1;
    }
    _T1IF = 0; // Clear interrupt flag
}
void _ISR _INT3Interrupt(void)
{
        if(_RD7 == 0){ //clockwise
            if(!_INT3EP)
                riktning = CW;
            else
                riktning = CCW;
        }
        if(_RD7 == 1){ //counter clockwise
            if(!_INT3EP)
                riktning = CCW;
            else
                riktning = CW;
        }
        _INT3EP = !_INT3EP;

        _INT3IF = 0;
}
void Init()
{
    TRISAbits.TRISA3 = 1;
    TRISDbits.TRISD15 = 0;
    _INT3IE = 1;
    _INT3EP = 0;//pos FLANK
    TMR1 = 0x0000;          // Clear timer counter.
    PR1 = 500-1;            // Interrupt every ms.
    T1CONbits.TCKPS = 0x1;  // Count at 4MHz/8.
    T1CONbits.TON = 1;      // Start timer.
    _T1IF = 0;              // Clear interrupt flag, just in case.
    _T1IE = 1;              // Enable timer interrupt.

    LcdInit();
    ADCInit();
    h_displayData = DisplayInit(h_displayData);
    h_input = UserInputInit(h_input);

}
int main(int argc, char** argv) {
    Init();
    char startFan;
    while(1)
    {
        if(startRead == 1){
            adc10Bit = ADCRead();
            temp = temp_calc(adc10Bit);
            h_displayData = SplitNumber(temp);
            startFan = checktemp(h_displayData.heltals, h_input.tempMinLimit, h_input.tempMaxLimit);
            LATDbits.LATD15 = startFan;
            startRead = 0;
        }
        
        
        if(riktning != 0)
        {
            h_input = EncoderPosition(h_input, riktning);
            riktning = 0;
        }
        if( ChangeOnRelease())
        {
            lcd_clear();
            h_input = ConfirmSelection( h_input);
            
        }
        if(startDraw == 1){
            WriteWindow(h_input, h_displayData);
            startDraw = 0;
        }

    }
    return (EXIT_SUCCESS);
}