/* 
 * NAME:
 * AUTHOR:
 * PROJECT:
 * DATE: 16 mars 2016, 09:43
 * CODE REVISION:
 * PURPOSE OF FILE:
 */


#ifndef USERINPUT_H
#define	USERINPUT_H


#include <stdlib.h>
#include <xc.h>
#include <libpic30.h>
#include "helperfunctions.h"

struct input
{
    int window;
    int button;
    int tempMaxLimit;
    int tempMinLimit;
};
/**
 ******************************************************************************
 * UserInputInit
 *      Function Description:
 *          Set the Temperature limits
 *          Set "window" och button that should be used at startup
 *      Input: struct input
 *      Output: struct input
 * ****************************************************************************
 */
struct input UserInputInit(struct input unInit);
/**
 ******************************************************************************
 * EncoderPosition
 *      Function Description:
 *          Set the limits for the encoder.
 *          Step the position CW or CCW 
 *          Rounded buffer
 *      Input: Struct input, direction(CW 1, CCW -1)
 *      Output: Struct input
 * ***************************************************************************** 
 */
struct input EncoderPosition(struct input inputPosition, int direction);
/**
 ******************************************************************************
 * ConfirmSelection
 *      Function Description:
 *          When the encoder button is pressed this function sets what window
 *          is being called next.
 *      Input: Struct input
 *      Output: Struct input
 * *****************************************************************************
 */
struct input ConfirmSelection(struct input inputPosition);

#endif	/* USERINPUT_H */

