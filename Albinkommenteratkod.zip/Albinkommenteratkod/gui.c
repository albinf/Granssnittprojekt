/*
 * NAME: GUI.C
 * AUTHOR:
 * PROJECT:
 * DATE: 16 mars 2016, 09:43
 * CODE REVISION:
 * PURPOSE OF FILE:
 */
#include "gui.h"
struct displayData DisplayInit(struct displayData unInitTemp){
    unInitTemp.decimals = 0;
    unInitTemp.heltals = 0;
    unInitTemp.firstDecimal = 0;
    return unInitTemp;

}


void WriteWindow(struct input inputPosition, struct displayData temp){
    char str[17];
    if(inputPosition.window == 0 && inputPosition.button == 0){//HOME
        lcd_gotoxy(0, 1);
        sprintf(str,"T:%d.%d |  CONFIG",temp.heltals,temp.firstDecimal);
        lcd_putstring(str);

        static int i = 0;
        i++;
        if(i == 50){
            lcd_gotoxy(0, 2);
            TempBar(temp.heltals,inputPosition.tempMinLimit);
            i = 0;
        }
    }
    else if(inputPosition.window == 0 && inputPosition.button == 1){//HOME och mark�r p� config
        lcd_gotoxy(0, 1);
        sprintf(str,"T:%d.%d | *CONFIG",temp.heltals,temp.firstDecimal);
        lcd_putstring(str);

        static int i = 0;
        i++;
        if(i == 50){
            lcd_gotoxy(0, 2);
            TempBar(temp.heltals,inputPosition.tempMinLimit);
            i = 0;
        }
    }
    else if(((inputPosition.window == 1) || (inputPosition.window == 2)) && inputPosition.button == 0){//CONFIG och mark�r min

        lcd_gotoxy(0, 1);
        sprintf(str,"*MIN:%d | MAX:%d",inputPosition.tempMinLimit,
                                       inputPosition.tempMaxLimit);
        lcd_putstring(str);

        lcd_gotoxy(0, 2);
        sprintf(str," Back");
        lcd_putstring(str);

    }
    else if(((inputPosition.window == 1) || (inputPosition.window == 3)) && inputPosition.button == 1){//CONFIG och mark�r max
        lcd_gotoxy(0, 1);
        sprintf(str," MIN:%d |*MAX:%d",inputPosition.tempMinLimit,
                                       inputPosition.tempMaxLimit);
        lcd_putstring(str);

        lcd_gotoxy(0, 2);
        sprintf(str," Back");
        lcd_putstring(str);


    }
    else if(inputPosition.window == 1 && inputPosition.button == 2){//CONFIG och mark�r back
        lcd_gotoxy(0, 1);
        sprintf(str," MIN:%d | MAX:%d",inputPosition.tempMinLimit,
                                       inputPosition.tempMaxLimit);
        lcd_putstring(str);

        lcd_gotoxy(0, 2);
        sprintf(str,"*Back");
        lcd_putstring(str);


    }
}

void TempBar(int temp, int tempMinLimit)
{
    lcd_clear();
    static int bars;
    bars = 0;
    int steg = 3; //After 3 degrees make another bar
    int k;
    for(k = tempMinLimit; k <= temp;) // calculate how many bars
    {
        bars = bars + 1;
        k = k + steg;
    }
    int i;
    for (i = 0; i<bars; i++){ // Draw the bars at row 2
        lcd_gotoxy(i, 2);
        lcd_putchar(0b11111111);
    }
}

struct displayData SplitNumber(unsigned int temp)
{
    struct displayData pDisplayData;
    int i;
    int number = 0;
    int decimal = 0;
    for(i = 0; i < 3; i++)
    {
        number = temp % 10;
        temp = temp / 10 ;
        decimal = decimal +number*ipow(10, i);
        if(i == 2){
            pDisplayData.firstDecimal = number;
        }
    }
    pDisplayData.heltals = temp;
    pDisplayData.decimals = decimal;
    return pDisplayData;
}