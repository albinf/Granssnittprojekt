#include "TEMP.h"


//uint16_t temp_decimalfix(uint16_t oldtemp){
//
//    int decimal = 0;
//    for(int i = 0; i < 3; i++)
//    {
//        printf( "%d\n", num % 10 );
//        num = num / 10 ;
//    }
//    printf( "%d\n", num  ) ;
//
//}

int temp_calc(uint16_t ADC_10bit)
{
    unsigned int temp;
    //temp = (-0.0391006843*ADC_10bit+50.0)*10;//*1000;
    temp = -39 * ADC_10bit+ 50000;
   // temp=(-391*adc*+50);
    return temp;
}

int checktemp(int temp, int tempminlimit, int tempmaxlimit)
{
    static int fan = 0;
    if (fan == 0)
    {
        if (temp >= tempmaxlimit)
        {
            fan = 1;
        }
    }
    else
    {
        if (temp <= tempminlimit)
        {
            fan = 0;
        }
    }
    return fan;
}



