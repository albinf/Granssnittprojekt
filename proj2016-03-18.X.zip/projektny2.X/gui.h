/* 
 * File:   gui.h
 * Author: Albin
 *
 * Created on den 18 mars 2016, 09:28
 */

#ifndef GUI_H
#define	GUI_H
#include <xc.h>
#include <stdint.h>
#include <stdbool.h>
#include <libpic30.h>

#include "userinput.h"  // To be able to use __delay_ms();



void writewindow(struct input inputPosition, int temp);
void temp_bar(int temp, int tempminlimit,int tempmaxlimit);




#endif	/* GUI_H */

