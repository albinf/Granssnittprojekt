/* 
 * File:   main.c
 * Author: heja1414
 *
 * Created on den 16 mars 2016, 09:42
 */

#include <stdio.h>
#include <stdlib.h>
#include "xc.h"
#include <libpic30.h>
#include "helperfunctions.h"
#include "userinput.h"
#include "lcd.h"
#include "temp.h"
#include "adc.h"
/*
 * 
 */
#define FOSC (8000000UL)
#define FCY (FOSC/2)

// CONFIG2
#pragma config POSCMOD = XT             // Primary Oscillator Select (XT Oscillator mode selected)
#pragma config OSCIOFNC = OFF           // Primary Oscillator Output Function (OSC2/CLKO/RC15 functions as CLKO (FOSC/2))
#pragma config FCKSM = CSDCMD           // Clock Switching and Monitor (Clock switching and Fail-Safe Clock Monitor are disabled)
#pragma config FNOSC = PRI              // Oscillator Select (Primary Oscillator (XT, HS, EC))
#pragma config IESO = ON                // Internal External Switch Over Mode (IESO mode (Two-Speed Start-up) enabled)

// CONFIG1
#pragma config WDTPS = PS32768          // Watchdog Timer Postscaler (1:32,768)
#pragma config FWPSA = PR128            // WDT Prescaler (Prescaler ratio of 1:128)
#pragma config WINDIS = OFF             // Watchdog Timer Window (Windowed Watchdog Timer enabled; FWDTEN must be 1)
#pragma config FWDTEN = OFF             // Watchdog Timer Enable (Watchdog Timer is disabled)
#pragma config ICS = PGx2               // Comm Channel Select (Emulator/debugger uses EMUC2/EMUD2)
#pragma config GWRP = OFF               // General Code Segment Write Protect (Writes to program memory are allowed)
#pragma config GCP = OFF                // General Code Segment Code Protect (Code protection is disabled)
#pragma config JTAGEN = ON

#define CW -1
#define CCW 1
uint16_t temp = 0;
uint16_t ADC_10bit = 0b0000000000;
int riktning = 0;
struct input h_input;
void _ISR _INT3Interrupt(void)
{
        if(_RD7 == 0){ //clockwise
            if(!_INT3EP)
                riktning = CW;
            else
                riktning = CCW;
        }
        if(_RD7 == 1){ //counter clockwise
            if(!_INT3EP)
                riktning = CCW;
            else
                riktning = CW;
        }
        _INT3EP = !_INT3EP;

        _INT3IF = 0;
}

//RD7,RA14  encoder
//RA3 KNAPP p� encoder
void init()
{

    //TRISDbits.TRISD6 = 1;
    TRISAbits.TRISA3 = 1;
    _INT3IE = 1;
    _INT3EP = 0;//pos FLANK

}
/*void Graphicsomething(){
    if(h_input.window == 0){

        lcd_gotoxy(0, 1);
        sprintf(str,"Temp: %d Config",
        h_input.button);
        lcd_putstring(str);

        lcd_gotoxy(0, 2);
        sprintf(str,"Grafic something");
        lcd_putstring(str);
    }
     if(h_input.window == 1){
         lcd_gotoxy(0, 1);
        sprintf(str,"Temp: %d Config",
        h_input.button);
        lcd_putstring(str);

        lcd_gotoxy(0, 2);
        sprintf(str,"Grafic something");
        lcd_putstring(str);

     }

}*/
char str[17];

int main(int argc, char** argv) {
    
    init();
    lcd_init();
    ADC_INIT();
    
    h_input = UserInputInit(h_input);

    while(1)
    {
         ADC_10bit = ADC_READ();
         temp = temp_calc(ADC_10bit);
        float float_temp = ((double)temp) / 10;
        int test = checktemp(float_temp, h_input.tempMinLimit, h_input.tempMaxLimit);
        //lcd_clear();
       // lcd_clear();


       if(riktning != 0)
       {
            h_input = EncoderPosition(h_input, riktning);
            riktning = 0;
       }

        if( ChangeOnRelease())
        {
            lcd_clear();
            h_input = ConfirmSelection( h_input);
            
        }




        lcd_gotoxy(0, 1);
        sprintf(str,"b: %d W: %d T:%.1f",
        h_input.button,
        h_input.window,
        float_temp);
        lcd_putstring(str);

        lcd_gotoxy(0, 2);
        sprintf(str,"1: %d 2: %d O:%d",
        h_input.tempMaxLimit,
        h_input.tempMinLimit,
        test);
        lcd_putstring(str);



        //lcd_putstring(str);
        //__delay_ms(50);
    }
    //input.blabla = 10;
    
    return (EXIT_SUCCESS);
}

