/* 
 * File:   main.c
 * Author: heja1414
 *
 * Created on den 22 mars 2016, 12:59
 */
#define FOSC (8000000UL)
#define FCY (FOSC/2)
#include <stdio.h>
#include <stdlib.h>
#include <libpic30.h>


// PIC24FJ128GA010 Configuration Bit Settings

// 'C' source line config statements

#include <xc.h>

// CONFIG2
#pragma config POSCMOD = XT             // Primary Oscillator Select (XT Oscillator mode selected)
#pragma config OSCIOFNC = OFF           // Primary Oscillator Output Function (OSC2/CLKO/RC15 functions as CLKO (FOSC/2))
#pragma config FCKSM = CSDCMD           // Clock Switching and Monitor (Clock switching and Fail-Safe Clock Monitor are disabled)
#pragma config FNOSC = PRI              // Oscillator Select (Primary Oscillator (XT, HS, EC))
#pragma config IESO = ON                // Internal External Switch Over Mode (IESO mode (Two-Speed Start-up) enabled)

// CONFIG1
#pragma config WDTPS = PS32768          // Watchdog Timer Postscaler (1:32,768)
#pragma config FWPSA = PR128            // WDT Prescaler (Prescaler ratio of 1:128)
#pragma config WINDIS = OFF             // Watchdog Timer Window (Windowed Watchdog Timer enabled; FWDTEN must be 1)
#pragma config FWDTEN = OFF             // Watchdog Timer Enable (Watchdog Timer is disabled)
#pragma config ICS = PGx2               // Comm Channel Select (Emulator/debugger uses EMUC2/EMUD2)
#pragma config GWRP = OFF               // General Code Segment Write Protect (Writes to program memory are allowed)
#pragma config GCP = OFF                // General Code Segment Code Protect (Code protection is disabled)
#pragma config JTAGEN = ON// JTAG Port Enable (JTAG port is enabled)



#define SDA_PORT PORTAbits.RA3
#define SCL_PORT PORTAbits.RA2

#define SDA_TRIS TRISAbits.TRISA3
#define SCL_TRIS TRISAbits.TRISA2

#define SDA_LAT LATAbits.LATA3
#define SCL_LAT LATAbits.LATA2

void _ISR INT2Interrupt()
{

}

/*
 * 
 */
void MainInit()
{
    I2C2BRG = 0x27;
    I2C2CON = 0b1000000000000000;
    I2C2ADD = 0X5A;





}

void I2CStart()
{
    I2C2CONbits.SEN = 1;
    while(I2C2CONbits.SEN == 1);
}
void I2CStop()
{
    I2C2CONbits.PEN = 1;
     while(I2C2CONbits.PEN == 1);
}
void I2CReStart()
{
    I2C2CONbits.RSEN = 1;
    while(I2C2CONbits.RSEN == 1);
}
/*void I2CWait()
{
     while ( ( SSP1CON2 & 0x1F ) || ( SSPSTAT & 0x04 ) );
}*/
void I2CSlaveAdress()
{
    I2C2TRN = 0b00011000;
   while(I2C2STATbits.TBF == 1);
}




void send_byte(int registeradd, int data)
{
    I2CStart();
    I2C2TRN = 0b10110100;
    while(I2C2STATbits.TRSTAT == 1);
    I2C2TRN = registeradd;
    while(I2C2STATbits.TRSTAT == 1);
    I2C2TRN = data;
    while(I2C2STATbits.TRSTAT == 1);
    I2CStop();
}


int main(int argc, char** argv) {

    int i = 0;
    MainInit();
    while(1)
    {
        I2CStart();
        I2C2TRN = 0b10110100;
        while(I2C2STATbits.TRSTAT == 1);
        I2C2TRN = 0x2B;
        while(I2C2STATbits.TRSTAT == 1);
        I2C2TRN = 0b00000001;
        while(I2C2STATbits.TRSTAT == 1);
        I2CStop();
        __delay_us(50);

    
    
    }
    return (EXIT_SUCCESS);
}

