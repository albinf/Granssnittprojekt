#include "UserInput.h"
#include "lcd.h"
#include "Helperfunctions.h"



//Number system,


void ButtonSelect(int direction ) // V�ljer f�nster n�r knapp trycks, Anropas n�r encoder knappen sl�pps
{
        if((Window == CONFIG) && (Button == B_MIN_LIMIT)) // g�r tillbaka till 0
	{
            MIN_LIMIT += direction
	}
        else if((Window == CONFIG) && (Button == B_MAX_LIMIT))
        {
            MAX_LIMIT += direction
        }
        else if((Window == CONFIG) && (Button == B_BACK))
        {
            Window = HOME;
        }
}

int Encoder_Position(int direction) //V�ljer knapp i f�nster eller �ndrar �vre/undreGr�ns beroende p� f�nster)
{//B�ttre namn ENCODER POSTION
    if(Window == CONFIG) //f�nster 1 =  kan �ndra �vreGr�ns
    {
        Configval = LimitModulo(3, direction, Configval);

    }
    return Configval;
}


