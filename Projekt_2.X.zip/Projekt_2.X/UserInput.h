#ifndef USERINPUT_H
#define	USERINPUT_H
#define CW 1
#define CCW -1
#include <xc.h>
#include <stdint.h>
#include <stdbool.h>
#include <libpic30.h>  // To be able to use __delay_ms();

uint16_t Window = HOME;
uint16_t Button = B_config;
uint16_t Configval = 0;

void Encoder_Position();
void Button_Select();

#endif